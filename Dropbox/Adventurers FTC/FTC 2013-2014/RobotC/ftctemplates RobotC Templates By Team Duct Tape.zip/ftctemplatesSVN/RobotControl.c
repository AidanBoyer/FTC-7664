
void initializeRobot()
{
  // Place code here to sinitialize servos to starting positions.
  // Sensors are automatically configured and setup by ROBOTC. They may need a brief time to stabilize.

  return;
}


/*add any functions that you need to control the robot in this file. */

void DriveForward(float inches, int power)
{
  //place code for robot to drive forward the Inputted distance at the inputted power
}

void DriveBackward(float inches, int power)
{
  //place code for robot to drive backward the Inputted distance at the inputted power
}

void TurnLeft(float degrees, int power)
{
  //place code for robot to turn left the inputted degrees at the inputted power
}

void TurnRight(float degrees, int power)
{
  //place code for robot to turn right the inputted degrees at the inputed power
}
